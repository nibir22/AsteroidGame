module CommonAsteroids {
    requires Common;
    exports dk.sdu.mmmi.cbse.common.asteroids;
}