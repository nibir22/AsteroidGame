module CommonBullet {
    requires Common;
    exports dk.sdu.mmmi.cbse.common.bullet;
}