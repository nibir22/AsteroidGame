Build the project from the root folder with the following Maven command:
mvn clean install

Run the project from root folder with following Maven command :
mvn exec:exec
